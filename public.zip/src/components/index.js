export { default as First } from './first/FirstPage';
export { default as Menu } from './menu/MenuPage';
export { default as Admin } from './admin/Admin';
export { default as Second } from './second/Second';
export { default as Third } from './third/Third';